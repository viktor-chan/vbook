At Raw Shorts we want to be able to continue bringing you the best
icons, graphics, designs and photos for your design projects. To help 
us keep the library up to date please read attribution instructions below:

You must attribute the image to its author.

In order to use a vector or a part of it, you must attribute it to RawShorts.com ,

How to attribute it?

For websites:

Please place this code on your website to accredit the author:
<a href="http://www.rawshorts.com”>Designed by Raw Shorts</a>

For printing:

Paste this text on the final work so the authorship is known.
- For example, in the acknowledgements chapter of a book:
“Icons designed and provided by RawShorts.com”


You are free to use and or modify this image:

- For both personal and commercial projects
- In a website or presentation template or application or as part of your design.

You are not allowed to:

- Sub-license, resell or rent it.